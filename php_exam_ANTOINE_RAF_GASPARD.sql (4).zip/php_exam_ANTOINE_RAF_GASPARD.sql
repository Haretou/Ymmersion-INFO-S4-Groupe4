-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Hôte : localhost:8889
-- Généré le : ven. 21 fév. 2025 à 09:37
-- Version du serveur : 8.0.40
-- Version de PHP : 8.3.14

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `php_exam_ANTOINE_RAF_GASPARD`
--

-- --------------------------------------------------------

--
-- Structure de la table `articles`
--

CREATE TABLE `articles` (
  `id` int NOT NULL,
  `title` varchar(100) NOT NULL,
  `description` text NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `stock` int NOT NULL,
  `image` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `user_id` int NOT NULL,
  `category_id` int DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Déchargement des données de la table `articles`
--

INSERT INTO `articles` (`id`, `title`, `description`, `price`, `stock`, `image`, `created_at`, `user_id`, `category_id`) VALUES
(1, 'carte pokémon ', 'Pikachu.', 699.99, 10, 'smartphone.jpg', '2025-02-17 08:45:51', 0, NULL),
(2, 'Booster pokémon', 'Casque sans fil avec réduction de bruit.', 199.99, 5, 'casque.jpg', '2025-02-17 08:45:51', 0, NULL),
(4, 'test', 'test', 11.00, 1, NULL, '2025-02-17 09:32:04', 0, NULL),
(5, 'pokémon', 'carte', 29.00, 1, '../uploads/img_67b304cc485764.78127059.JPG', '2025-02-17 09:43:40', 0, NULL),
(6, 'raf', 'raf', 100.00, 1, '../uploads/img_67b305d8b61124.95516682.jpg', '2025-02-17 09:48:08', 0, NULL),
(7, 'a', 'a', 2.00, 10, '../uploads/img_67b3191d1aaa02.36506806.png', '2025-02-17 11:10:21', 0, NULL),
(8, 'Carte Pokémon magnéton ar 112/106', 'Carte Pokémon sortie de booster et mise sous sleeve', 10.00, 1, '../uploads/img_67b70ed5e93b61.96381269.png', '2025-02-20 11:15:33', 5, 2),
(9, 'Carte Pokémon terapagos SAR 226/187 sv8a', '\r\nCarte Pokémon état mint sortie de booster et mise sous sleeves', 10.00, 1, '../uploads/img_67b70f6714bd73.14677264.png', '2025-02-20 11:17:59', 5, 2),
(10, 'Booster Évolutions Prismatiques neuf scellé FR', '\r\nBooster de l’extension Évolutions Prismatiques neuf et scellé', 15.00, 99, '../uploads/img_67b70fc1e0e700.16251033.png', '2025-02-20 11:19:29', 5, 1),
(11, 'ETB coffret dresseur d’élite FR ev8.5 évolutions prismatiques', 'ETB coffret dresseur d’élite FR ev8.5 évolutions prismatiques', 140.00, 5, '../uploads/img_67b7100f0f1cb4.39323454.jpg', '2025-02-20 11:20:47', 5, 3),
(12, 'carte pokémon pikachu 057/191', 'carte état mint.', 10.00, 1, '../uploads/img_67b8376555a1f8.01011817.JPG', '2025-02-21 08:20:53', 5, 2),
(13, 'Carte pokémon Pomdrochi 010/187', 'carte état mint ', 3.00, 3, '../uploads/img_67b837975e2465.41099940.JPG', '2025-02-21 08:21:43', 5, 2),
(14, 'carte pokémon Milobellus 028/106', 'carte état mint', 3.00, 1, '../uploads/img_67b837d485e242.05331171.JPG', '2025-02-21 08:22:44', 5, 2),
(15, 'carte pokémon roue de fer ex Fa ', 'carte état mint ', 3.00, 1, '../uploads/img_67b8380e24fb07.57278671.JPG', '2025-02-21 08:23:42', 5, 2),
(16, 'Carte pokémon phyllali SAR 202/187', 'carte état mint', 3.00, 1, '../uploads/img_67b838540cf5f7.31597436.JPG', '2025-02-21 08:24:52', 5, 2),
(17, 'carte pokémon pyrolli 200/187', 'carte pokémon état mint', 50.00, 1, '../uploads/img_67b83876a6a602.32551417.JPG', '2025-02-21 08:25:26', 5, 2);

-- --------------------------------------------------------

--
-- Structure de la table `billing_addresses`
--

CREATE TABLE `billing_addresses` (
  `id` int NOT NULL,
  `user_id` int NOT NULL,
  `name` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `city` varchar(100) NOT NULL,
  `zip` varchar(20) NOT NULL,
  `country` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Déchargement des données de la table `billing_addresses`
--

INSERT INTO `billing_addresses` (`id`, `user_id`, `name`, `address`, `city`, `zip`, `country`) VALUES
(1, 3, 'cabanes antoine', '63 rue georges braque', 'montpellier', '34000', 'France'),
(2, 3, 'cabanes antoine', '63 rue georges braque', 'montpellier', '34000', 'France'),
(3, 3, 'cabanes antoine', '63 rue georges braque', 'montpellier', '34000', 'France'),
(4, 3, 'cabanes antoine', '63 rue georges braque', 'montpellier', '34000', 'France'),
(5, 3, 'cabanes antoine', '63 rue georges braque', 'montpellier', '34000', 'France'),
(6, 3, 'cabanes antoine', '63 rue georges braque', 'montpellier', '34000', 'France'),
(7, 3, 'cabanes antoine', '63 rue georges braque', 'montpellier', '34000', 'France'),
(8, 3, 'cabanes antoine', '63 rue georges braque', 'montpellier', '34000', 'France'),
(9, 3, 'cabanes antoine', '63 rue georges braque', 'montpellier', '34000', 'France'),
(10, 3, 'cabanes antoine', '63 rue georges braque', 'montpellier', '34000', 'France'),
(11, 3, 'cabanes antoine', '63 rue georges braque', 'montpellier', '34000', 'France'),
(12, 3, 'cabanes antoine', '63 rue georges braque', 'montpellier', '34000', 'France'),
(13, 3, 'cabanes antoine', '63 rue georges braque', 'montpellier', '34000', 'France'),
(14, 3, 'cabanes antoine', '63 rue georges braque', 'montpellier', '34000', 'France'),
(15, 5, 'cabanes antoine', '63 rue georges braque', 'montpellier', '34000', 'France'),
(16, 5, 'cabanes antoine', '63 rue georges braque', 'montpellier', '34000', 'France'),
(17, 5, 'cabanes antoine', '63 rue georges braque', 'montpellier', '34000', 'France'),
(18, 5, 'cabanes antoine', '63 rue georges braque', 'montpellier', '34000', 'France'),
(19, 5, 'cabanes antoine', '63 rue georges braque', 'montpellier', '34000', 'France'),
(20, 5, 'cabanes antoine', '63 rue georges braque', 'montpellier', '34000', 'France'),
(21, 5, 'cabanes antoine', '63 rue georges braque', 'montpellier', '34000', 'France'),
(22, 5, 'cabanes antoine', '63 rue georges braque', 'montpellier', '34000', 'France'),
(23, 5, 'cabanes antoine', '63 rue georges braque', 'montpellier', '34000', 'France'),
(24, 5, 'cabanes antoine', '63 rue georges braque', 'montpellier', '34000', 'France'),
(25, 5, 'cabanes antoine', '63 rue georges braque', 'montpellier', '34000', 'France'),
(26, 5, 'cabanes antoine', '63 rue georges braque', 'montpellier', '34000', 'France');

-- --------------------------------------------------------

--
-- Structure de la table `cart`
--

CREATE TABLE `cart` (
  `id` int NOT NULL,
  `user_id` int NOT NULL,
  `article_id` int NOT NULL,
  `quantity` int NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Structure de la table `categories`
--

CREATE TABLE `categories` (
  `id` int NOT NULL,
  `name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Déchargement des données de la table `categories`
--

INSERT INTO `categories` (`id`, `name`) VALUES
(1, 'Booster'),
(2, 'Carte Pokémon'),
(3, 'Boxbreak');

-- --------------------------------------------------------

--
-- Structure de la table `favorites`
--

CREATE TABLE `favorites` (
  `user_id` int NOT NULL,
  `article_id` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Déchargement des données de la table `favorites`
--

INSERT INTO `favorites` (`user_id`, `article_id`) VALUES
(5, 5),
(5, 6);

-- --------------------------------------------------------

--
-- Structure de la table `orders`
--

CREATE TABLE `orders` (
  `id` int NOT NULL,
  `user_id` int NOT NULL,
  `total_price` decimal(10,2) NOT NULL,
  `order_date` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `status` enum('En attente','Payée','Expédiée','Livrée','Annulée') DEFAULT 'En attente',
  `shipping_id` int NOT NULL,
  `billing_id` int NOT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `payment_method` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Déchargement des données de la table `orders`
--

INSERT INTO `orders` (`id`, `user_id`, `total_price`, `order_date`, `status`, `shipping_id`, `billing_id`, `created_at`, `payment_method`) VALUES
(1, 3, 4.00, '2025-02-18 13:44:43', 'En attente', 1, 1, '2025-02-18 14:44:43', 'balance'),
(2, 3, 29.00, '2025-02-18 16:41:28', 'En attente', 10, 10, '2025-02-18 17:41:28', 'balance'),
(3, 3, 29.00, '2025-02-18 16:46:37', 'En attente', 11, 11, '2025-02-18 17:46:37', 'balance'),
(4, 3, 29.00, '2025-02-18 16:49:33', 'En attente', 12, 12, '2025-02-18 17:49:33', 'balance'),
(5, 5, 2.00, '2025-02-20 10:36:56', 'En attente', 15, 15, '2025-02-20 11:36:56', 'balance'),
(6, 5, 2.00, '2025-02-20 10:37:23', 'En attente', 17, 17, '2025-02-20 11:37:23', 'balance'),
(7, 5, 2.00, '2025-02-20 10:39:40', 'En attente', 18, 18, '2025-02-20 11:39:40', 'balance'),
(8, 5, 2.00, '2025-02-20 10:46:40', 'En attente', 19, 19, '2025-02-20 11:46:40', 'balance'),
(9, 5, 2.00, '2025-02-20 11:27:45', 'En attente', 20, 20, '2025-02-20 12:27:45', 'balance'),
(10, 5, 2.00, '2025-02-20 11:32:46', 'En attente', 21, 21, '2025-02-20 12:32:46', 'balance'),
(11, 5, 2.00, '2025-02-20 11:41:40', 'En attente', 22, 22, '2025-02-20 12:41:40', 'balance'),
(12, 5, 2.00, '2025-02-20 11:42:11', 'En attente', 23, 23, '2025-02-20 12:42:11', 'balance'),
(13, 5, 10.00, '2025-02-20 11:45:42', 'En attente', 24, 24, '2025-02-20 12:45:42', 'balance'),
(14, 5, 10.00, '2025-02-20 11:49:10', 'En attente', 25, 25, '2025-02-20 12:49:10', 'balance'),
(15, 5, 10.00, '2025-02-20 11:50:59', 'En attente', 26, 26, '2025-02-20 12:50:59', 'balance');

-- --------------------------------------------------------

--
-- Structure de la table `order_items`
--

CREATE TABLE `order_items` (
  `id` int NOT NULL,
  `order_id` int NOT NULL,
  `product_id` int NOT NULL,
  `quantity` int NOT NULL,
  `price` decimal(10,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Déchargement des données de la table `order_items`
--

INSERT INTO `order_items` (`id`, `order_id`, `product_id`, `quantity`, `price`) VALUES
(1, 3, 5, 1, 29.00),
(2, 4, 5, 1, 29.00),
(3, 5, 7, 1, 2.00),
(4, 6, 7, 1, 2.00),
(5, 7, 7, 1, 2.00),
(6, 8, 7, 1, 2.00),
(7, 9, 7, 1, 2.00),
(8, 10, 7, 1, 2.00),
(9, 11, 7, 1, 2.00),
(10, 12, 7, 1, 2.00),
(11, 13, 8, 1, 10.00),
(12, 14, 8, 1, 10.00),
(13, 15, 8, 1, 10.00);

-- --------------------------------------------------------

--
-- Structure de la table `panier`
--

CREATE TABLE `panier` (
  `id` int NOT NULL,
  `user_id` int NOT NULL,
  `article_id` int NOT NULL,
  `quantity` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Déchargement des données de la table `panier`
--

INSERT INTO `panier` (`id`, `user_id`, `article_id`, `quantity`) VALUES
(1, 3, 6, 1),
(2, 3, 6, 1),
(3, 3, 6, 1),
(4, 3, 7, 1),
(5, 3, 7, 1);

-- --------------------------------------------------------

--
-- Structure de la table `reviews`
--

CREATE TABLE `reviews` (
  `user_id` int NOT NULL,
  `article_id` int NOT NULL,
  `rating` int DEFAULT NULL,
  `comment` text
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Déchargement des données de la table `reviews`
--

INSERT INTO `reviews` (`user_id`, `article_id`, `rating`, `comment`) VALUES
(5, 6, 4, 'bof');

-- --------------------------------------------------------

--
-- Structure de la table `shipping_addresses`
--

CREATE TABLE `shipping_addresses` (
  `id` int NOT NULL,
  `user_id` int NOT NULL,
  `name` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `city` varchar(100) NOT NULL,
  `zip` varchar(20) NOT NULL,
  `country` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Déchargement des données de la table `shipping_addresses`
--

INSERT INTO `shipping_addresses` (`id`, `user_id`, `name`, `address`, `city`, `zip`, `country`) VALUES
(1, 3, 'cabanes antoine', '63 rue georges braque', 'montpellier', '34000', 'France'),
(2, 3, 'cabanes antoine', '63 rue georges braque', 'montpellier', '34000', 'France'),
(3, 3, 'cabanes antoine', '63 rue georges braque', 'montpellier', '34000', 'France'),
(4, 3, 'cabanes antoine', '63 rue georges braque', 'montpellier', '34000', 'France'),
(5, 3, 'cabanes antoine', '63 rue georges braque', 'montpellier', '34000', 'France'),
(6, 3, 'cabanes antoine', '63 rue georges braque', 'montpellier', '34000', 'France'),
(7, 3, 'cabanes antoine', '63 rue georges braque', 'montpellier', '34000', 'France'),
(8, 3, 'cabanes antoine', '63 rue georges braque', 'montpellier', '34000', 'France'),
(9, 3, 'cabanes antoine', '63 rue georges braque', 'montpellier', '34000', 'France'),
(10, 3, 'cabanes antoine', '63 rue georges braque', 'montpellier', '34000', 'France'),
(11, 3, 'cabanes antoine', '63 rue georges braque', 'montpellier', '34000', 'France'),
(12, 3, 'cabanes antoine', '63 rue georges braque', 'montpellier', '34000', 'France'),
(13, 3, 'cabanes antoine', '63 rue georges braque', 'montpellier', '34000', 'France'),
(14, 3, 'cabanes antoine', '63 rue georges braque', 'montpellier', '34000', 'France'),
(15, 5, 'cabanes antoine', '63 rue georges braque', 'montpellier', '34000', 'France'),
(16, 5, 'cabanes antoine', '63 rue georges braque', 'montpellier', '34000', 'France'),
(17, 5, 'cabanes antoine', '63 rue georges braque', 'montpellier', '34000', 'France'),
(18, 5, 'cabanes antoine', '63 rue georges braque', 'montpellier', '34000', 'France'),
(19, 5, 'cabanes antoine', '63 rue georges braque', 'montpellier', '34000', 'France'),
(20, 5, 'cabanes antoine', '63 rue georges braque', 'montpellier', '34000', 'France'),
(21, 5, 'cabanes antoine', '63 rue georges braque', 'montpellier', '34000', 'France'),
(22, 5, 'cabanes antoine', '63 rue georges braque', 'montpellier', '34000', 'France'),
(23, 5, 'cabanes antoine', '63 rue georges braque', 'montpellier', '34000', 'France'),
(24, 5, 'cabanes antoine', '63 rue georges braque', 'montpellier', '34000', 'France'),
(25, 5, 'cabanes antoine', '63 rue georges braque', 'montpellier', '34000', 'France'),
(26, 5, 'cabanes antoine', '63 rue georges braque', 'montpellier', '34000', 'France');

-- --------------------------------------------------------

--
-- Structure de la table `stocks`
--

CREATE TABLE `stocks` (
  `id` int NOT NULL,
  `article_id` int NOT NULL,
  `stock` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Structure de la table `users`
--

CREATE TABLE `users` (
  `id` int NOT NULL,
  `username` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `balance` decimal(10,2) DEFAULT '0.00',
  `role` enum('user','admin') DEFAULT 'user',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Déchargement des données de la table `users`
--

INSERT INTO `users` (`id`, `username`, `email`, `password`, `balance`, `role`, `created_at`) VALUES
(2, 'user1', 'user1@example.com', 'ef92b778bafe771e89245b89ecbc08a44a4e166c06659911881f383d4473e94f', 500.00, 'user', '2025-02-17 08:43:25'),
(3, 'raf34', 'raf@gmail.com', '$2y$10$mka1Eiw99Gan7EnrisHAFOrlRMrWXrIQbc/uG.niM6evsCX3Vcznm', 7.00, 'user', '2025-02-17 09:15:51'),
(4, 'gasp', 'gasp@gmail.com', '$2y$10$ROC5kGu1sdbRe1UqqI8YeOj/TfCWs4zoMMZPlxdDPTqrTGHDRqpdO', 0.00, 'user', '2025-02-17 15:20:35'),
(5, 'cabsi34', 'cabanesantoine@icloud.com', '$2y$10$rM3MF5ARumt.7YgWTdc6A.Yt//iexhjHFQTPxIzEPgxUC55dUi5/S', 75.00, 'admin', '2025-02-19 08:55:17');

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `articles`
--
ALTER TABLE `articles`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_category_id` (`category_id`);

--
-- Index pour la table `billing_addresses`
--
ALTER TABLE `billing_addresses`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Index pour la table `cart`
--
ALTER TABLE `cart`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `article_id` (`article_id`);

--
-- Index pour la table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `favorites`
--
ALTER TABLE `favorites`
  ADD PRIMARY KEY (`user_id`,`article_id`),
  ADD KEY `article_id` (`article_id`);

--
-- Index pour la table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `shipping_id` (`shipping_id`),
  ADD KEY `billing_id` (`billing_id`);

--
-- Index pour la table `order_items`
--
ALTER TABLE `order_items`
  ADD PRIMARY KEY (`id`),
  ADD KEY `order_id` (`order_id`),
  ADD KEY `product_id` (`product_id`);

--
-- Index pour la table `panier`
--
ALTER TABLE `panier`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `article_id` (`article_id`);

--
-- Index pour la table `reviews`
--
ALTER TABLE `reviews`
  ADD PRIMARY KEY (`user_id`,`article_id`),
  ADD KEY `article_id` (`article_id`);

--
-- Index pour la table `shipping_addresses`
--
ALTER TABLE `shipping_addresses`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Index pour la table `stocks`
--
ALTER TABLE `stocks`
  ADD PRIMARY KEY (`id`),
  ADD KEY `article_id` (`article_id`);

--
-- Index pour la table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT pour les tables déchargées
--

--
-- AUTO_INCREMENT pour la table `articles`
--
ALTER TABLE `articles`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT pour la table `billing_addresses`
--
ALTER TABLE `billing_addresses`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;

--
-- AUTO_INCREMENT pour la table `cart`
--
ALTER TABLE `cart`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT pour la table `orders`
--
ALTER TABLE `orders`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT pour la table `order_items`
--
ALTER TABLE `order_items`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT pour la table `panier`
--
ALTER TABLE `panier`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT pour la table `shipping_addresses`
--
ALTER TABLE `shipping_addresses`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;

--
-- AUTO_INCREMENT pour la table `stocks`
--
ALTER TABLE `stocks`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `users`
--
ALTER TABLE `users`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- Contraintes pour les tables déchargées
--

--
-- Contraintes pour la table `articles`
--
ALTER TABLE `articles`
  ADD CONSTRAINT `fk_category_id` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`);

--
-- Contraintes pour la table `billing_addresses`
--
ALTER TABLE `billing_addresses`
  ADD CONSTRAINT `billing_addresses_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

--
-- Contraintes pour la table `cart`
--
ALTER TABLE `cart`
  ADD CONSTRAINT `cart_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `cart_ibfk_2` FOREIGN KEY (`article_id`) REFERENCES `articles` (`id`) ON DELETE CASCADE;

--
-- Contraintes pour la table `favorites`
--
ALTER TABLE `favorites`
  ADD CONSTRAINT `favorites_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `favorites_ibfk_2` FOREIGN KEY (`article_id`) REFERENCES `articles` (`id`);

--
-- Contraintes pour la table `orders`
--
ALTER TABLE `orders`
  ADD CONSTRAINT `orders_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `orders_ibfk_2` FOREIGN KEY (`shipping_id`) REFERENCES `shipping_addresses` (`id`),
  ADD CONSTRAINT `orders_ibfk_3` FOREIGN KEY (`billing_id`) REFERENCES `billing_addresses` (`id`);

--
-- Contraintes pour la table `order_items`
--
ALTER TABLE `order_items`
  ADD CONSTRAINT `order_items_ibfk_1` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `order_items_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `articles` (`id`) ON DELETE CASCADE;

--
-- Contraintes pour la table `panier`
--
ALTER TABLE `panier`
  ADD CONSTRAINT `panier_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `panier_ibfk_2` FOREIGN KEY (`article_id`) REFERENCES `articles` (`id`);

--
-- Contraintes pour la table `reviews`
--
ALTER TABLE `reviews`
  ADD CONSTRAINT `reviews_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `reviews_ibfk_2` FOREIGN KEY (`article_id`) REFERENCES `articles` (`id`);

--
-- Contraintes pour la table `shipping_addresses`
--
ALTER TABLE `shipping_addresses`
  ADD CONSTRAINT `shipping_addresses_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

--
-- Contraintes pour la table `stocks`
--
ALTER TABLE `stocks`
  ADD CONSTRAINT `stocks_ibfk_1` FOREIGN KEY (`article_id`) REFERENCES `articles` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
